from django.db import models

# Create your models here.
class Course(models.Model):
    pname=models.CharField(max_length=50)
    mname=models.CharField(max_length=50,unique=True)
    mdesc=models.CharField(max_length=500)
    fname=models.CharField(max_length=50)
    mprice=models.FloatField()

class Trainers(models.Model):
    tname=models.CharField(max_length=50)
    tmod=models.CharField(max_length=50)
    tdesc=models.CharField(max_length=500)

class Testimonials(models.Model):
    sname=models.CharField(max_length=50)
    sdes=models.CharField(max_length=50)
    scom=models.CharField(max_length=500)
    