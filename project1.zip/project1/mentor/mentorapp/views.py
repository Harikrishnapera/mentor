from django.shortcuts import render,redirect
from django.http import HttpResponse,HttpResponseRedirect
from mentorapp.models import Course,Trainers,Testimonials

# Create your views here.
def index(request):
    content={}
    content['data']=Course.objects.all()
    content['trs']=Trainers.objects.all()
    content['d']=Testimonials.objects.all()
    return render(request,"index.html",content)

    #return HttpResponse("<h1><em>Hello World</em></h1>")
def about(request):
    content={}
    content['d']=Testimonials.objects.all()
    return render(request,"about.html",content)
def courses(request):
    content={}
    content['data']=Course.objects.all()
    return render(request,"courses.html",content)
def trainers(request):
    content={}
    content['trs']=Trainers.objects.all()
    return render(request,"trainers.html",content)
def events(request):
    context={'name':'itvedant'}
    return render(request,"events.html",context)
def pricing(request):
    context={'name':'itvedant'}
    return render(request,"pricing.html",context)
def contact(request):
    context={'name':'itvedant'}
    return render(request,"contact.html",context)