from django.contrib import admin
from mentorapp.models import Course,Trainers,Testimonials
# Register your models here.
admin.site.site_header="ITVEDANT Admin Panel"
#Changing Title in the tab
admin.site.site_title="Courses"
admin.site.register(Course)
admin.site.register(Trainers)
admin.site.register(Testimonials)
